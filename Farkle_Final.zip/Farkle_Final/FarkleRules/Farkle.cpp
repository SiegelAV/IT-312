#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>

/*
* Austin Siegel
* IT-312
* August 12, 2024
* Final Project: Farkle!
* 
* This is the final project for IT-312 using the dice game Farkle. Each building block from previous weeks have been integrated into this version of the final project.
* The pseudocode can be found in the Pseudocode.cpp file in this project. I modified my original pseuocode so it matches the latest version of the project. 
* Farkle.cpp implements a simple dice game for multiple players, where the goal is to reach a target score (10,000) by rolling dice and accumulating points based on 
* the rolls. The game logic is encapsulated in two main classes: Player and DiceGame. The Player class represents an individual player, tracking their score and ID. 
* The DiceGame class manages the overall gameplay, including rolling dice, calculating scores, reading game rules from a file, and handling each player's turn. The main() 
* function is minimal, simply initializing the game with a specified number of players and starting the game loop. The code is designed to be modular and easy to extend, 
* with clear separation of responsibilities between the classes. 
* 
* There was no genuine struggle creating this project, since the building blocks were already completed. I did take some time to restructure the building blocks so the 
* integrated smoothly into the Player and DiceGame classes. My original design had a lot of the functionality in main(), which made the code a little harder to read. I
* intentionally kept main() small for the sake of organization and coding best practices. 
* 
*/

const int TARGET_SCORE = 10000;
const int NUM_DICE = 6;
const int NUM_PLAYERS = 2; // or more

//Building Block Three: Player Class Functionality 
class Player {
public:

    // Default constructor initializes id to 0 and score to 0
    Player() : id(0), score(0) {}

    // Constructor that initializes id to the given value, score is set to 0
    Player(int id) : id(id), score(0) {}

    // Getter method for the score
    int getScore() const {
        return score;
    }

    // Method to add the score from a turn to the player's total score
    void addScore(int turnScore) {
        score += turnScore;
    }

    // Getter method for the player's ID
    int getId() const {
        return id;
    }

private:
    int id;    // Unique identifier for the player
    int score; // Player's total score
};

class DiceGame {
public:
    // Constructor initializes the game with a given number of players
    DiceGame(int numPlayers) : players(numPlayers), currentPlayer(0) {
        srand(time(0)); // Seed the random number generator with the current time
        for (int i = 0; i < numPlayers; ++i) {
            players[i] = Player(i + 1); // Initialize each player with a unique ID starting from 1
        }
    }

    // Main function to start and manage the game loop
    void play() {
        readTheRules(); // Display the game rules to the players

        while (true) {
            // Get the current player
            Player& player = players[currentPlayer];
            std::cout << "Player " << player.getId() << "'s turn\n";

            // Take the player's turn and update the score
            int turnScore = takeTurn(player);

            // Check if the player has reached the target score to win the game
            if (player.getScore() >= TARGET_SCORE) {
                std::cout << "Player " << player.getId() << " wins!\n";
                break; // End the game loop if there's a winner
            }

            // Move to the next player in a circular manner
            currentPlayer = (currentPlayer + 1) % players.size();
        }
    }

private:
    std::vector<Player> players; // Vector holding all players in the game
    int currentPlayer;           // Index of the current player taking a turn

    // Function to roll the dice and return the results
    std::vector<int> rollDice() {
        std::vector<int> diceRolls(NUM_DICE); // Create a vector to store the results of dice rolls
        for (int i = 0; i < NUM_DICE; ++i) {
            diceRolls[i] = rand() % 6 + 1; // Generate a random number between 1 and 6
        }
        return diceRolls;
    }

    // Building Block One: Function to calculate the score from the dice rolls
    int calculateScore(std::vector<int>& diceRolls) {
        std::vector<int> counts(6, 0); // Vector to count occurrences of each dice face (1-6)
        int score = 0; // Initialize the score

        // Count occurrences of each dice face
        for (int roll : diceRolls) {
            counts[roll - 1]++;
        }

        // Calculate the score based on the game rules
        if (counts[0] >= 3) {
            score += 1000 * (counts[0] / 3);
            counts[0] %= 3;
        }
        if (counts[1] >= 3) {
            score += 200 * (counts[1] / 3);
            counts[1] %= 3;
        }
        if (counts[2] >= 3) {
            score += 300 * (counts[2] / 3);
            counts[2] %= 3;
        }
        if (counts[3] >= 3) {
            score += 400 * (counts[3] / 3);
            counts[3] %= 3;
        }
        if (counts[4] >= 3) {
            score += 500 * (counts[4] / 3);
            counts[4] %= 3;
        }
        if (counts[5] >= 3) {
            score += 600 * (counts[5] / 3);
            counts[5] %= 3;
        }

        // Additional points for remaining 1s and 5s
        score += 100 * counts[0];
        score += 50 * counts[4];

        return score; // Return the calculated score
    }

    // Function to manage a single player's turn
    int takeTurn(Player& player) {
        int turnScore = 0; // Score for the current turn
        bool turnOver = false; // Flag to indicate whether the turn is over

        while (!turnOver) {
            // Roll the dice and display the results
            std::vector<int> diceRolls = rollDice();
            std::cout << "Rolled: ";
            for (int roll : diceRolls) {
                std::cout << roll << " ";
            }
            std::cout << "\n";

            // Calculate the score from the dice rolls
            int score = calculateScore(diceRolls);
            if (score == 0) {
                std::cout << "Farkle! No points scored this turn.\n";
                turnOver = true; // End the turn if no points were scored
                turnScore = 0; // Reset the turn score to 0
            }
            else {
                turnScore += score; // Add the score to the turn's total
                std::cout << "Current turn score: " << turnScore << "\n";

                // Ask the player if they want to roll again or end their turn
                char input;
                std::cout << "Do you want to roll again or end turn? (r/e)\n";
                std::cin >> input;

                if (input == 'e') {
                    turnOver = true; // End the turn if the player chooses to
                }
            }
        }

        // Update the player's total score with the turn score
        player.addScore(turnScore);
        std::cout << "Player " << player.getId() << "'s total score: " << player.getScore() << "\n";

        return turnScore; // Return the score for this turn
    }

    // Building Block Four: Function to read and display the game rules from a file
    void readTheRules() {
        std::ifstream rulesFile("game_rules.txt"); // Open the rules file

        if (rulesFile.is_open()) {
            std::string line;
            std::cout << "Game Rules:\n";
            while (std::getline(rulesFile, line)) {
                std::cout << line << '\n'; // Print each line of the rules file
            }
            rulesFile.close(); // Close the file after reading
        }
        else {
            std::cout << "Unable to open file!\n"; // Error message if the file can't be opened
        }
    }
};

int main() {
    DiceGame game(NUM_PLAYERS); // Initialize the game with the specified number of players
    game.play(); // Start the game
    return 0; // End of the program
}