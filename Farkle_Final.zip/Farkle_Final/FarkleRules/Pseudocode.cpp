/*
* Building Block Two: Pseudocode
* 
CLASS Player:
    PRIVATE VARIABLE id
    PRIVATE VARIABLE score

    METHOD Constructor()
        SET id TO 0
        SET score TO 0

    METHOD Constructor(id)
        SET id TO id
        SET score TO 0

    METHOD getScore()
        RETURN score


    METHOD addScore(turnScore)
        INCREASE score BY turnScore

    METHOD getId()
        RETURN id

END CLASS

CLASS DiceGame:
    PRIVATE VARIABLE players
    PRIVATE VARIABLE currentPlayer

    METHOD Constructor(numPlayers)
        INITIALIZE random number generator
        FOR each player from 1 to numPlayers
            CREATE new Player with id as player number
            ADD Player to players list
        END FOR

    METHOD play()
        DISPLAY game rules
        WHILE True
            SET player TO current player in players list
            DISPLAY "Player " + player ID + "'s turn"
            CALL takeTurn(player)

            IF player's score is greater than or equal to target score
                DISPLAY "Player " + player ID + " wins!"
                BREAK the loop

            UPDATE currentPlayer to the next player in a circular manner
        END WHILE

    METHOD rollDice()
        CREATE list to store dice rolls
        FOR each dice from 1 to number of dice
            GENERATE random number between 1 and 6
            ADD number to dice rolls list
        END FOR
        RETURN dice rolls list

    METHOD calculateScore(diceRolls)
        CREATE list to count occurrences of each dice face
        SET score to 0

        FOR each roll in dice rolls
            INCREASE the corresponding count in the list
        END FOR

        FOR each dice face 1 to 6
            IF count of dice face is greater than or equal to 3
                CALCULATE points for 3 of a kind
                REMOVE those dice from the count
            END IF
        END FOR

        ADD additional points for remaining 1s and 5s

        RETURN calculated score

    METHOD takeTurn(player)
        SET turnScore to 0
        SET turnOver to False

        WHILE turnOver is False
            CALL rollDice() and store the result
            DISPLAY the rolled dice

            CALL calculateScore(diceRolls) and store the score
            IF score is 0
                DISPLAY "Farkle! No points scored this turn."
                SET turnOver to True
                SET turnScore to 0
            ELSE
                ADD score to turnScore
                DISPLAY current turn score
                PROMPT player to roll again or end turn

                IF player chooses to end turn
                    SET turnOver to True
                END IF
            END IF
        END WHILE

        ADD turnScore to player's total score
        DISPLAY player's total score

        RETURN turnScore

    METHOD readTheRules()
        OPEN the game rules file

        IF file is open
            DISPLAY "Game Rules:"
            FOR each line in the file
                DISPLAY line
            END FOR
            CLOSE the file
        ELSE
            DISPLAY "Unable to open file!"
        END IF

END CLASS

MAIN METHOD
    CREATE DiceGame with number of players
    CALL play()
END MAIN METHOD
*/