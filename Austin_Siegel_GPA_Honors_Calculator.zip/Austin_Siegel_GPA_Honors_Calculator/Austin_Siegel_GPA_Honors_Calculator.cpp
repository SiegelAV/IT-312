// Austin_Siegel_GPA_Honors_Calculator.cpp : This file contains the 'main' function. Program execution begins and ends there.
// IT-312 Software Development with C++
// July 12, 2024
// GPA & Honors Calculator

/* This program functions as a simple GPA and honors calculator. It prompts the user to enter four 
*  grades in letter form (A, B, C, D, or F) and stores them in char variables. The program then converts 
*  the letter grades to their numerical GPA counterparts (4.0, 3.0, 2.0, 1.0, 0.0) by passing them through 
*  the convertLetterGradeToGPA() method. The program then averages them to find the cumulative GPA and 
*  uses this value to decide if the user receives any honors. This decision is amde with the logic provided 
*  in the bool variables in the bottom code block. Once these calculations are complete, the program outputs 
*  the user's cumulative GPA and if they received any honors. This is ouptut in the form of true/false statements. 
* 
*  I did not encounter any issues creating this code, but it can be modified further if the assignment asked for 
*  more detail such as grades between the letter grades (A-, B+, C+, etc.).
*/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// Accepts char grade1, grade2, grade3, grade4 as inpout and generates numerical counterpart
double convertLetterGradeToGPA(char letterGrade) {
    switch (letterGrade) {
    case 'A': return 4.0;
    case 'B': return 3.0;
    case 'C': return 2.0;
    case 'D': return 1.0;
    case 'F': return 0.0;
    default: return -1.0; // Invalid grade
    }
}

int main() {
    // Initialize variables
    char grade1, grade2, grade3, grade4;
    double gpa1, gpa2, gpa3, gpa4;
    double GPA;

    // Prompt the user to enter the letter grades
    cout << "Enter grade 1 (A, B, C, D, F): ";
    cin >> grade1;
    cout << "Enter grade 2 (A, B, C, D, F): ";
    cin >> grade2;
    cout << "Enter grade 3 (A, B, C, D, F): ";
    cin >> grade3;
    cout << "Enter grade 4 (A, B, C, D, F): ";
    cin >> grade4;

    // Convert letter grades to GPA values
    gpa1 = convertLetterGradeToGPA(grade1);
    gpa2 = convertLetterGradeToGPA(grade2);
    gpa3 = convertLetterGradeToGPA(grade3);
    gpa4 = convertLetterGradeToGPA(grade4);

    // Check for invalid grades
    if (gpa1 == -1.0 || gpa2 == -1.0 || gpa3 == -1.0 || gpa4 == -1.0) {
        cout << "Invalid grade entered. Please enter grades as A, B, C, D, or F." << endl;
        return 1;
    }

    // Calculate the GPA
    GPA = (gpa1 + gpa2 + gpa3 + gpa4) / 4.0;

    // Set output format for GPA
    cout << fixed << setprecision(2);

    // Display the GPA
    cout << "Your GPA is " << GPA << "." << endl;

    // Determine and display honor levels
    bool summaCumLaude = GPA >= 3.9;
    bool magnaCumLaude = GPA >= 3.8 && GPA < 3.9;
    bool cumLaude = GPA >= 3.65 && GPA < 3.8;
    bool withoutHonors = GPA < 3.65;

    // Output Honors status as true/false statements
    cout << "Graduating summa cum laude is " << (summaCumLaude ? "true" : "false") << "." << endl;
    cout << "Graduating magna cum laude is " << (magnaCumLaude ? "true" : "false") << "." << endl;
    cout << "Graduating cum laude is " << (cumLaude ? "true" : "false") << "." << endl;
    cout << "Graduating without honors is " << (withoutHonors ? "true" : "false") << "." << endl;

    return 0;
}